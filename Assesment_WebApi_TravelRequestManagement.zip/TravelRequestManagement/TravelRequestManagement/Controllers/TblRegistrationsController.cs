﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelRequestManagement.Models;

namespace TravelRequestManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TblRegistrationsController : ControllerBase
    {
        private readonly TravelDbContext _context;

        public TblRegistrationsController(TravelDbContext context)
        {
            _context = context;
        }

        // GET: api/TblRegistrations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TblRegistration>>> GetTblRegistrations()
        {
            return await _context.TblRegistrations.ToListAsync();
        }

        // GET: api/TblRegistrations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TblRegistration>> GetTblRegistration(int id)
        {
            var tblRegistration = await _context.TblRegistrations.FindAsync(id);

            if (tblRegistration == null)
            {
                return NotFound();
            }

            return tblRegistration;
        }

        // PUT: api/TblRegistrations/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTblRegistration(int id, TblRegistration tblRegistration)
        {
            if (id != tblRegistration.EmpId)
            {
                return BadRequest();
            }

            _context.Entry(tblRegistration).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblRegistrationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TblRegistrations
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<TblRegistration>> PostTblRegistration(TblRegistration tblRegistration)
        {
            _context.TblRegistrations.Add(tblRegistration);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (TblRegistrationExists(tblRegistration.EmpId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetTblRegistration", new { id = tblRegistration.EmpId }, tblRegistration);
        }

        // DELETE: api/TblRegistrations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTblRegistration(int id)
        {
            var tblRegistration = await _context.TblRegistrations.FindAsync(id);
            if (tblRegistration == null)
            {
                return NotFound();
            }

            _context.TblRegistrations.Remove(tblRegistration);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TblRegistrationExists(int id)
        {
            return _context.TblRegistrations.Any(e => e.EmpId == id);
        }
    }
}
