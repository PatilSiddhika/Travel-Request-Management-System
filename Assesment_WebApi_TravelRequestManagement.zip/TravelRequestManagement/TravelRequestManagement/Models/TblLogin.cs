﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TravelRequestManagement.Models
{
    public partial class TblLogin
    {
        public int LId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string UserType { get; set; }
    }
}
