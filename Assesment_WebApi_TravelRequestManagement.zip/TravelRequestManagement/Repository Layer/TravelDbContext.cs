﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace TravelRequestManagement.Models
{
    public partial class TravelDbContext : DbContext
    {
        public TravelDbContext()
        {
        }

        public TravelDbContext(DbContextOptions<TravelDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblLogin> TblLogins { get; set; }
        public virtual DbSet<TblProject> TblProjects { get; set; }
        public virtual DbSet<TblRegistration> TblRegistrations { get; set; }
        public virtual DbSet<TblRequest> TblRequests { get; set; }
        public virtual DbSet<TblRole> TblRoles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=LAPTOP-3NT9ECFU;Database= TravelDb;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<TblLogin>(entity =>
            {
                entity.HasKey(e => e.LId);

                entity.ToTable("tblLogin");

                entity.Property(e => e.LId).HasColumnName("l_id");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblProject>(entity =>
            {
                entity.HasKey(e => e.ProjectId);

                entity.ToTable("tblProject");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.ProjectName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblRegistration>(entity =>
            {
                entity.HasKey(e => e.EmpId);

                entity.ToTable("tblRegistration");

                entity.Property(e => e.EmpId).HasColumnName("emp_id");

                entity.Property(e => e.Address)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LId).HasColumnName("l_id");

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.HasOne(d => d.LIdNavigation)
                    .WithMany(p => p.InverseLIdNavigation)
                    .HasForeignKey(d => d.LId)
                    .HasConstraintName("FK_tblLogin_tblRegistration");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.InverseRole)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK_tblRoles_tblRegistration");
            });

            modelBuilder.Entity<TblRequest>(entity =>
            {
                entity.HasKey(e => e.RequestId);

                entity.ToTable("tblRequest");

                entity.Property(e => e.RequestId).HasColumnName("request_id");

                entity.Property(e => e.CauseTravel)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("cause_travel");

                entity.Property(e => e.Destination).HasColumnName("destination");

                entity.Property(e => e.EmpId).HasColumnName("emp_id");

                entity.Property(e => e.FromDate)
                    .HasColumnType("date")
                    .HasColumnName("from_date");

                entity.Property(e => e.Mode)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("mode");

                entity.Property(e => e.NoDays).HasColumnName("no_days");

                entity.Property(e => e.Priority)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("priority");

                entity.Property(e => e.ProjectId).HasColumnName("project_id");

                entity.Property(e => e.Source)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("source");

                entity.Property(e => e.Status)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("status");

                entity.Property(e => e.ToDate)
                    .HasColumnType("date")
                    .HasColumnName("to_date");

                entity.HasOne(d => d.Emp)
                    .WithMany(p => p.InverseEmp)
                    .HasForeignKey(d => d.EmpId)
                    .HasConstraintName("FK_tblRegistration_tblRequest");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.InverseProject)
                    .HasForeignKey(d => d.ProjectId)
                    .HasConstraintName("FK_tblProject_tblRequest");
            });

            modelBuilder.Entity<TblRole>(entity =>
            {
                entity.HasKey(e => e.RoleId);

                entity.ToTable("tblRoles");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.RoleType)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("role_type");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
