using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Layer.Models
{
  public partial class Project : BaseEntity
  {
    public Project()
    {
      Requests = new HashSet<Request>();
    }

    public int ProjectId { get; set; }
    public string ProjectName { get; set; }

    public virtual ICollection<Request> Requests{ get; set; }
  }
}
