using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain_Layer.Models;


namespace Domain_Layer.Entity_Mapper
{
  public class RegistrationMap : IEntityTypeConfiguration<Registration>
  {
    public void Configure(EntityTypeBuilder<Registration> builder)
    {
      builder.HasKey(x => x.EmpId)
          .HasName("pk_emp_id");

      builder.Property(e => e.login_Id)
                .HasColumnName("l_id");
      builder.Property(e => e.RoleId)
                .HasColumnName("role_id");

      builder.Property(x => x.FirstName)
          .HasColumnName("FirstName")
          .HasColumnType("Varchar(50)")
          .IsRequired();
      builder.Property(x => x.LastName)
         .HasColumnName("LastName")
         .HasColumnType("Varchar(50)")
         .IsRequired();

      builder.Property(x => x.Age)
          .HasColumnName("Age")
          .HasColumnType("int")
          .IsRequired();
      builder.Property(x => x.Gender)
          .HasColumnName("Gender")
          .HasColumnType("Varchar(50)")
          .IsRequired();
      builder.Property(x => x.Address)
        .HasColumnName("Address")
        .HasColumnType("Varchar(100)")
        .IsRequired();
      builder.Property(e => e.PhoneNo)
                .HasMaxLength(10)
                .HasColumnName("PhoneNo")
                .IsFixedLength(true);
      builder.HasOne(d => d.Login)
                .WithMany(p => p.Registrations)
                .HasForeignKey(d => d.login_Id)
                .HasConstraintName("FK_Registration_Logins");
      builder.HasOne(d => d.Role)
                .WithMany(p => p.Registrations)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK_Registration_Roles");
    }
  }
}
