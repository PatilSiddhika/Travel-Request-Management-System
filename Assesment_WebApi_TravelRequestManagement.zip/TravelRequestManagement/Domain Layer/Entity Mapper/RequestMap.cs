using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain_Layer.Models;

namespace Domain_Layer.Entity_Mapper
{
  public class RequestMap : IEntityTypeConfiguration<Request>
  {
    public void Configure(EntityTypeBuilder<Request> builder)
    {
      builder.HasKey(x => x.request_Id)
         
          .HasName("pk_request_id");

      builder.Property(x => x.request_Id)
        .ValueGeneratedOnAdd()
                .HasColumnName("request_Id")
                .HasColumnType("INT");

      _ = builder.Property(e => e.EmpId)
                .HasColumnName("emp_id");

      builder.Property(e => e.ProjectId)
                .HasColumnName("project_id");


      builder.Property(x => x.CauseTravel)
          .HasColumnName("cause_travel")
          .HasColumnType("Varchar(100)")
          .IsRequired();
      builder.Property(x => x.Source)
         .HasColumnName("source")
         .HasColumnType("Varchar(100)")
         .IsRequired();

      builder.Property(x => x.Destination)
          .HasColumnName("destination")
          .HasColumnType("Varchar(100)")
          .IsRequired();
      builder.Property(x => x.Mode)
          .HasColumnName("mode")
          .HasColumnType("Varchar(100)")
          .IsRequired();
      builder.Property(x => x.FromDate)
        .HasColumnName("from_date")
        .HasColumnType("date")
        .IsRequired();
      builder.Property(e => e.ToDate)
                
                .HasColumnName("to_date")
                 .HasColumnType("date")
                 .IsRequired();
      builder.Property(e => e.NoDays)

                .HasColumnName("no_days")
                 .HasColumnType("int")
                 .IsRequired();
      builder.Property(e => e.Priority)

                .HasColumnName("priority")
                 .HasColumnType("Varchar(20)")
                 .IsRequired();

      builder.Property(e => e.Status)

                .HasColumnName("status")
                 .HasColumnType("Varchar(200)")
                 .IsRequired();

      builder.HasOne(d => d.Project)
                .WithMany(p => p.Requests)
                .HasForeignKey(d => d.ProjectId)
                .HasConstraintName("FK_Request_Projects");
      builder.HasOne(d => d.Registrations)
                .WithMany(p => p.Requests)
                .HasForeignKey(d => d.EmpId)
                .HasConstraintName("FK_Request_Registrations");
    }
  }
}
