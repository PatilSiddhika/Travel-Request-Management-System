import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-request',
  templateUrl: './employee-request.component.html',
  styleUrls: ['./employee-request.component.css']
})
export class EmployeeRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
