import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-request-list',
  templateUrl: './employee-request-list.component.html',
  styleUrls: ['./employee-request-list.component.css']
})
export class EmployeeRequestListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
