import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRequestListComponent } from './employee-request-list.component';

describe('EmployeeRequestListComponent', () => {
  let component: EmployeeRequestListComponent;
  let fixture: ComponentFixture<EmployeeRequestListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeRequestListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
